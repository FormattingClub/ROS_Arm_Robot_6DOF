#!/usr/bin/env python
#coding:utf-8

import rospy
from arm_driver.msg import joint_value

from pyfirmata import Arduino,util
'''
global joint1 = 3
global joint2 = 5
global joint3 = 6
global joint4 = 9
global joint5 = 10
global joint6 = 11
'''
arm = Arduino('/dev/ttyUSB0',baudrate=115200)

def callback(data):
	rospy.loginfo(rospy.get_caller_id() + ']--->Joint1 Angle :%d', data.joint1_angle)
	arm.servo_config(3,0,255,data.joint1_angle)
	
	rospy.loginfo(rospy.get_caller_id() + ']--->Joint2 Angle :%d', data.joint2_angle)
	arm.servo_config(5,0,255,data.joint2_angle)

	rospy.loginfo(rospy.get_caller_id() + ']--->Joint3 Angle :%d', data.joint3_angle)
	arm.servo_config(6,0,255,data.joint4_angle)

	rospy.loginfo(rospy.get_caller_id() + ']--->Joint4 Angle :%d', data.joint4_angle)
	arm.servo_config(9,0,255,data.joint4_angle)

	rospy.loginfo(rospy.get_caller_id() + ']--->Joint5 Angle :%d', data.joint5_angle)
	arm.servo_config(10,0,255,data.joint5_angle)

	rospy.loginfo(rospy.get_caller_id() + ']--->Joint6 Angle :%d', data.joint6_angle)
	arm.servo_config(11,0,255,data.joint6_angle)

def driver():
	rospy.init_node('Arm_Driver', anonymous=True)
	rospy.Subscriber('joint_value', joint_value, callback)
	rospy.spin()

if __name__ == '__main__':
	driver()
arm.exit()
